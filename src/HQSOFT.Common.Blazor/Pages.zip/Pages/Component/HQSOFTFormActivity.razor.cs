﻿using HQSOFT.Common.Blazor.Pages.Common;
using HQSOFT.Common.Blazor.Pages.RichTextEdit;
using HQSOFT.Common.Comments;
using HQSOFT.Common.Notifications;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Auditing;
using Volo.Abp.AuditLogging;
using Volo.Abp.Identity;
using static DevExpress.Drawing.Printing.Internal.DXPageSizeInfo;

namespace HQSOFT.Common.Blazor.Pages.Component
{
	public partial class HQSOFTFormActivity
	{
		public const string UrlName = "ScreenUrl";

		private string authServerUrl;
		private readonly IConfiguration _configuration;
		private readonly IAuditingManager _auditingManager;

		[Parameter]
		public Guid DocId { get; set; }

		[Parameter]
		public string Url { get; set; }

		[Parameter]
		public bool IsActive { get; set; }


		private HQSOFTRichTextEdit richTextEditRef;
		private string contentHTML;
		private string contentText;
		private string contentDelta;

		private Guid? userId = Guid.Empty;

		Guid editingCommentId = Guid.Empty; // Biến để lưu trữ Id của comment đang được chỉnh sửa 

		private string desiredUrl = "";
		private bool IsEditing { get; set; } = false;

		private List<string> urlEntityList = new List<string>();
		private List<string> MentionedUserIds { get; set; } = new List<string>();
		private int TotalCount { get; set; }
		private int CurrentPage { get; set; } = 1;
		private string CurrentSorting { get; set; } = string.Empty;
		private int PageSize { get; } = LimitedResultRequestDto.MaxMaxResultCount;

		private GetCommentsInput FilterCommentList { get; set; }
		private IReadOnlyList<CommentDto> commentList { get; set; }
		private List<CommentDto> commentsList { get; set; } = new List<CommentDto>();

		private List<AuditLogDto> auditLogsList { get; set; } = new List<AuditLogDto>();
		private List<EntityChangeDto> entityChangesList { get; set; } = new List<EntityChangeDto>();
		private IReadOnlyList<EntityChangeDto> entityChangeList { get; set; } = new List<EntityChangeDto>();
		private GetIdentityUsersInput FilterUser { get; set; }
		private IReadOnlyList<IdentityUserDto> UserList { get; set; }

		private HubConnection _hubConnection;

		protected override async Task OnInitializedAsync()
		{
			await GetConnectSignalR();
			await GetUserAsync();
			await GetCommentListAsync();
			StateHasChanged();
			await base.OnInitializedAsync();
		}
		public HQSOFTFormActivity(IConfiguration configuration, IAuditingManager auditingManager)
		{
			_configuration = configuration;
			_auditingManager = auditingManager;
			authServerUrl = _configuration["AuthServer:Authority"];

			FilterUser = new GetIdentityUsersInput
			{
				MaxResultCount = PageSize,
				SkipCount = (CurrentPage - 1) * PageSize,
				Sorting = CurrentSorting
			};
			UserList = new List<IdentityUserDto>();

			FilterCommentList = new GetCommentsInput
			{
				MaxResultCount = PageSize,
				SkipCount = (CurrentPage - 1) * PageSize,
				Sorting = CurrentSorting
			};
			commentList = new List<CommentDto>();
		}

		private async Task GetUserAsync()
		{
			FilterUser.MaxResultCount = PageSize;
			FilterUser.SkipCount = (CurrentPage - 1) * PageSize;
			FilterUser.Sorting = CurrentSorting;

			var result = await IdentityUserAppService.GetListAsync(FilterUser);
			UserList = result.Items;
			TotalCount = (int)result.TotalCount;
			StateHasChanged();
		}

		public async Task GetCommentListAsync()
		{
			FilterCommentList.MaxResultCount = PageSize;
			FilterCommentList.SkipCount = (CurrentPage - 1) * PageSize;

			var result = await CommentsAppService.GetListAsync(FilterCommentList);
			commentsList = result.Items.OrderByDescending(m => m.CreationTime).ToList();
			TotalCount = (int)result.TotalCount;
			StateHasChanged();
		}

		async Task UpdateCommentContent(Guid commentId, string newContent)
		{
			try
			{
				CommentDto comment = await CommentsAppService.GetAsync(commentId); // Lấy thông tin comment hiện tại từ cơ sở dữ liệu
				CommentUpdateDto updateDto = new CommentUpdateDto
				{
					Id = commentId,
					Content = newContent,
					DocId = comment.DocId,
					Url = comment.Url,
					FromUserId = comment.FromUserId,
					ConcurrencyStamp = comment.ConcurrencyStamp // Truyền giá trị của ConcurrencyStamp từ comment hiện tại
				};

				await CommentsAppService.UpdateAsync(commentId, updateDto);
				await Notify.Success(L["Notification:Edit"]);
				await GetCommentListAsync();
			}
			catch (Exception ex)
			{
				await HandleErrorAsync(ex);
			}
		}

		private async Task GetEntityChangeAsync()
		{
			var entityChanges = await AuditLogsAppService.GetEntityChangesAsync(new GetEntityChangesDto
			{
				MaxResultCount = LimitedResultRequestDto.MaxMaxResultCount,
				EntityId = DocId.ToString()
			});
			entityChangeList = entityChanges.Items;
			StateHasChanged();
		}

		private async Task GetHistoryListAsync()
		{
			var tempEntityChangesList = new List<EntityChangeDto>();
			var tempUrlList = new List<string>();
			auditLogsList.Clear();
			entityChangesList.Clear();
			urlEntityList.Clear();

			foreach (var entityChange in entityChangeList.Where(x =>
				(x.EntityId == DocId.ToString() && x.ChangeType == EntityChangeType.Created) ||
				(x.EntityId == DocId.ToString() && x.ChangeType == EntityChangeType.Updated)))
			{
				var auditLog = await AuditLogsAppService.GetAsync(entityChange.AuditLogId);

				var extraProperties = auditLog.ExtraProperties;
				var docUrl = extraProperties[UrlName];
				string desiredUrl = GetDesiredUrl(docUrl.ToString());
				 
				auditLogsList.Add(auditLog);
				entityChangesList.Add(entityChange);
				urlEntityList.Add(desiredUrl);
			}
			Console.WriteLine("auditLogsList.Count()" + auditLogsList.Count());
			Console.WriteLine("urlEntityList.Count()" + urlEntityList.Count());
			Console.WriteLine("entityChangesList.Count()" + entityChangesList.Count());
			StateHasChanged();
		}

		public async Task SetIsNotEditing(Guid commentId)
		{
			if (editingCommentId == commentId)
			{
				string newContent = await richTextEditRef.GetHTML(); // Lấy nội dung đã chỉnh sửa từ trình soạn thảo
				await UpdateCommentContent(editingCommentId, newContent); // Cập nhật nội dung vào cơ sở dữ liệu
				IsEditing = false;
				StateHasChanged(); // Cập nhật giao diện người dùng
			}
		}

		public async Task SetIsEditing(Guid commentId)
		{
			editingCommentId = commentId;
			IsEditing = true;
			StateHasChanged(); // Cập nhật giao diện người dùng
		}

		public async Task CancelEditing(Guid commentId)
		{
			if (editingCommentId == commentId)
			{
				IsEditing = false;
				StateHasChanged();
			}
		}

		public async Task HandleCommentAdded()
		{
			await GetCommentListAsync();
			StateHasChanged();
		}


		#region Truncate Text 
		public static string TruncateText(string text, int maxLength) // Cắt chuỗi
		{
			if (text.Length <= maxLength)
				return text;

			return text.Substring(0, maxLength) + "...";
		}
		#endregion

		#region Get Uri
		public string GetDesiredUrl(string inputUrl)
		{
			string trimmedData = inputUrl.Trim('[', ']');
			string cleanedData = trimmedData.Replace("\\", "").Replace("\"", ""); // Loại bỏ ký tự "\", "\" và ký tự nháy kép "\"" 
			string url = cleanedData;// Lấy URL từ chuỗi đã được làm sạch 
			string[] parts = url.Split('/'); // Tách chuỗi URL thành các phần tử 
			if (parts.Length >= 4) // Kiểm tra đủ phần tử để tạo URL
			{
				// Lấy phần "/AccountReceivable/CustomerClasses/" từ phần tử thứ 3 và thứ 4
				desiredUrl = "/" + parts[3] + "/" + parts[4] + "/";
				// Cắt bỏ ký tự "/" cuối cùng
				desiredUrl = desiredUrl.TrimEnd('/');
			}

			return desiredUrl;
		}

		public List<string> GetDesiredUrls(string inputUrl)
		{
			List<string> desiredUrls = new List<string>();

			string[] urls = inputUrl.Split(',');

			foreach (string url in urls)
			{
				string trimmedData = url.Trim('[', ']');
				string cleanedData = trimmedData.Replace("\\", "").Replace("\"", "");
				string singleUrl = cleanedData;

				string[] parts = singleUrl.Split('/');

				if (parts.Length >= 4)
				{
					string desiredUrl = "/" + parts[3] + "/" + parts[4] + "/";
					desiredUrl = desiredUrl.TrimEnd('/');
					desiredUrls.Add(desiredUrl);
				}
				else
				{
					Console.WriteLine("URL không hợp lệ: " + singleUrl);
				}
			}

			return desiredUrls;
		}
		#endregion

		#region Get Time 
		public string GetTimeAgo(DateTime creationTime)
		{
			TimeSpan timeDifference = DateTime.Now - creationTime;

			if (timeDifference.TotalSeconds < 60)
			{
				return $"{(int)timeDifference.TotalSeconds} seconds ago";
			}
			else if (timeDifference.TotalMinutes < 60)
			{
				return $"{(int)timeDifference.TotalMinutes} minutes ago";
			}
			else if (timeDifference.TotalHours < 24)
			{
				return $"{(int)timeDifference.TotalHours} hours ago";
			}
			else
			{
				return $"{(int)timeDifference.TotalDays} days ago";
			}
		}
		#endregion

		#region SignalR
		public async Task GetConnectSignalR()
		{
			var tokenResult = await TokenProvider.RequestAccessToken();
			var apiURL = Configuration.GetValue<string>("SignalR:HistoryUrl");
			try
			{
				if (tokenResult.TryGetToken(out var token))
				{
					_hubConnection = new HubConnectionBuilder()
									.WithUrl($"{apiURL}", options =>
									{
										options.AccessTokenProvider = async () => await Task.FromResult(token.Value);
									}).Build();

					_hubConnection.On("ReceiveHistory",
					() =>
					{
						CallDataLoad();
						StateHasChanged();
					});

					await _hubConnection.StartAsync();
					await GetEntityChangeAsync();
					await GetHistoryListAsync();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error starting HubConnection: " + ex.Message);
			}
		}

		private void CallDataLoad()
		{
			Task.Run(async () =>
			{
				await GetEntityChangeAsync();
				await GetHistoryListAsync();
			});
		}

		public bool IsConnected => _hubConnection.State == HubConnectionState.Connected;

		public void Dispose()
		{
			_ = _hubConnection.DisposeAsync();
		}

		#endregion
	}
}
